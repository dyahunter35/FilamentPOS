<?php

return [
    'navigation' => [
        'group' => 'لوحة التحكم',
        'label' => 'لوحة التحكم',
        'plural_label' => 'لوحات التحكم',
        'model_label' => 'لوحة التحكم',
    ],
    'heading' => 'لوحة التحكم',
    'subheading' => 'نظرة عامة على أداء متجرك',
    

];
